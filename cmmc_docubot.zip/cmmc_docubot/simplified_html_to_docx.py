#!/usr/bin/env python3
"""
Simplified HTML to DOCX Converter Script

This script converts HTML content to DOCX format using a template,
with a focus on simplicity and reliability.
"""

import os
import sys
import argparse
import re
from bs4 import BeautifulSoup, NavigableString
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL

# --- Default spacing constants ---
DEFAULT_AFTER_SPACING = Pt(6)
HEADING_AFTER_SPACING_NORMAL = Pt(6)
HEADING_AFTER_SPACING_BEFORE_LIST = Pt(2) # Reduced space if heading is followed by a list
PARAGRAPH_AFTER_SPACING_BEFORE_LIST = Pt(2)
HEADING_BEFORE_SPACING = Pt(18)
LIST_ITEM_AFTER_SPACING = Pt(2)
LIST_DEFAULT_BEFORE_SPACING = Pt(3)


def parse_arguments():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description='Convert HTML content to DOCX using a template')
    parser.add_argument('--input', required=True, help='Path to input HTML file')
    parser.add_argument('--output', required=True, help='Path to output DOCX file')
    parser.add_argument('--template', default='template/template.docx', help='Path to template DOCX file')
    parser.add_argument('--images-dir', default='images', help='Directory containing images referenced in HTML')
    parser.add_argument('--metadata', help='Path to metadata YAML file')
    return parser.parse_args()

def extract_metadata(soup):
    """Extract metadata from HTML content."""
    metadata = {}
    meta_div = soup.select_one('div.metadata')
    if meta_div:
        for meta_tag in meta_div.find_all('meta'):
            name = meta_tag.get('name')
            content = meta_tag.get('content')
            if name and content:
                metadata[name] = content
    return metadata

def default_font_settings(doc):
    """Set default font for the entire document to Arial."""
    styles = doc.styles
    default_style_names = ['Normal', 'BodyText', 'Body Text', 'Default Paragraph Font']
    for style_name in default_style_names:
        if style_name in styles:
            try:
                style = styles[style_name]
                style.font.name = "Arial"
            except KeyError:
                print(f"Warning: Style '{style_name}' not found in template.")
            break

    if 'Caption' in styles:
        try:
            caption_style = styles['Caption']
            caption_style.font.name = "Arial"
            caption_style.font.italic = True
        except KeyError:
            print("Warning: Style 'Caption' not found in template.")
    
    for i in range(1, 7):
        heading_name = f'Heading {i}'
        if heading_name in styles:
            try:
                heading_style = styles[heading_name]
                heading_style.font.name = "Arial"
            except KeyError:
                print(f"Warning: Style '{heading_name}' not found in template.")

def update_title_page_table(doc, metadata):
    """Update title page information in tables."""
    field_formats = {
        '<TITLE>': {'size': Pt(36), 'bold': True, 'font': 'Arial', 'color': RGBColor(255, 255, 255)},
        '<Sub-Title>': {'size': Pt(28), 'bold': False, 'font': 'Arial', 'color': RGBColor(255, 255, 255)},
        'Prepared for:': {'size': Pt(28), 'bold': True, 'font': 'Arial', 'color': RGBColor(255, 255, 255)},
        '<Client Name>': {'size': Pt(28), 'bold': False, 'font': 'Arial', 'color': RGBColor(255, 255, 255)},
        '<Date of Submission>': {'size': Pt(18), 'bold': False, 'font': 'Arial', 'color': RGBColor(255, 255, 255)}
    }
    placeholder_map = {
        '<TITLE>': metadata.get('title', ''),
        '<Sub-Title>': metadata.get('subtitle', ''),
        '<Client Name>': metadata.get('client-name', ''),
        '<Date of Submission>': metadata.get('date', metadata.get('submission-date', ''))
    }
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for paragraph in cell.paragraphs:
                    text = paragraph.text.strip()
                    format_spec = field_formats.get(text)
                    replacement_text = placeholder_map.get(text)
                    current_format_spec = None
                    
                    if replacement_text is not None:
                        paragraph.clear()
                        run = paragraph.add_run(replacement_text)
                        current_format_spec = format_spec if format_spec else field_formats.get(text, {})
                    elif format_spec:
                        paragraph.clear()
                        run = paragraph.add_run(text)
                        current_format_spec = format_spec
                    else:
                        continue

                    if current_format_spec:
                        if 'size' in current_format_spec: run.font.size = current_format_spec['size']
                        if 'bold' in current_format_spec: run.font.bold = current_format_spec['bold']
                        if 'font' in current_format_spec: run.font.name = current_format_spec['font']
                        if 'color' in current_format_spec: run.font.color.rgb = current_format_spec['color']

def simple_update_metadata(doc, metadata):
    """Update document metadata using a combination of approaches."""
    submission_date = metadata.get('date', metadata.get('submission-date', ''))
    placeholders = {
        '<Date of Submission>': submission_date,
        '<TITLE>': metadata.get('title', ''), '<Title>': metadata.get('title', ''),
        '<Sub-Title>': metadata.get('subtitle', ''), '<Subtitle>': metadata.get('subtitle', ''),
        '<Client Name>': metadata.get('client-name', '')
    }
    for p in doc.paragraphs:
        for placeholder, value in placeholders.items():
            if placeholder in p.text:
                for run in p.runs: # Replace in runs to preserve formatting
                    if placeholder in run.text:
                        run.text = run.text.replace(placeholder, value)
    update_title_page_table(doc, metadata)

def simple_add_list(doc, list_soup, ordered=False, after_spacing=DEFAULT_AFTER_SPACING, before_spacing=LIST_DEFAULT_BEFORE_SPACING, indent_level=0):
    """Add a list to the document, handling nesting and hanging indents."""
    if indent_level == 0:
        text_left_indent = Inches(0.25)
    else:
        text_left_indent = Inches(0.25 + (indent_level * 0.25))
    hanging_indent_value = Inches(-0.1)

    if indent_level == 0 and before_spacing > Pt(0):
        if doc.paragraphs:
            last_doc_p = doc.paragraphs[-1]
            # Check if the last paragraph has content or has default spacing that isn't already minimal
            if (last_doc_p.text.strip() or last_doc_p.runs) and \
               (last_doc_p.paragraph_format.space_after is None or last_doc_p.paragraph_format.space_after > Pt(2)):
                spacing_p = doc.add_paragraph()
                spacing_p.paragraph_format.space_before = Pt(0)
                spacing_p.paragraph_format.space_after = before_spacing
                for r_ in spacing_p.runs: r_.clear()
        else: # Doc is empty or has no paragraphs yet from content elements
            spacing_p = doc.add_paragraph()
            spacing_p.paragraph_format.space_before = Pt(0)
            spacing_p.paragraph_format.space_after = before_spacing
            for r_ in spacing_p.runs: r_.clear()


    direct_list_items = [child for child in list_soup.children if child.name == 'li']
    for i, item_li in enumerate(direct_list_items, 1):
        p = doc.add_paragraph()
        li_text_parts = []
        nested_list_element = None
        for content_child in item_li.children:
            if content_child.name in ('ul', 'ol'):
                nested_list_element = content_child
                break
            if isinstance(content_child, NavigableString):
                li_text_parts.append(str(content_child)) # Keep spaces for joining
            elif content_child.name:
                li_text_parts.append(content_child.get_text()) # get_text preserves inner tags' text
        
        li_text = "".join(li_text_parts).strip() # Join then strip

        if ordered:
            prefix_text = f"{i}. "
        else:
            bullets = ["•", "◦", "▪"]
            prefix_text = f"{bullets[indent_level % len(bullets)]} "
        
        prefix_run = p.add_run(prefix_text)
        prefix_run.font.name = "Arial"
        
        # Handle inline formatting like <strong> and <em> within li_text if needed
        # For simplicity, current version adds li_text as a single run.
        # To handle inline, parse item_li children again for text and tags.
        text_run = p.add_run(li_text)
        text_run.font.name = "Arial"
            
        p.paragraph_format.left_indent = text_left_indent
        p.paragraph_format.first_line_indent = hanging_indent_value
        
        is_last_item_in_current_list = (i == len(direct_list_items))
        if nested_list_element:
            p.paragraph_format.space_after = Pt(0)
        elif is_last_item_in_current_list:
            # Only the very last item of the entire list structure (outermost call) gets full after_spacing
            p.paragraph_format.space_after = after_spacing if indent_level == 0 else LIST_ITEM_AFTER_SPACING
        else:
            p.paragraph_format.space_after = LIST_ITEM_AFTER_SPACING

        if nested_list_element:
            simple_add_list(doc, nested_list_element,
                            ordered=(nested_list_element.name == 'ol'),
                            after_spacing=after_spacing, # Propagate for the very end
                            before_spacing=Pt(0),
                            indent_level=indent_level + 1)

def simple_add_image(doc, img_soup, images_dir, after_spacing=DEFAULT_AFTER_SPACING):
    """Add an image to the document using a simple approach."""
    image_src = img_soup.get('src')
    image_alt = img_soup.get('alt', '')
    width_inches = Inches(6)
    img_path = os.path.join(images_dir, image_src)

    if not os.path.exists(img_path):
        alternate_path = image_src
        if os.path.exists(alternate_path): img_path = alternate_path
        else:
            print(f"Warning: Image not found: {image_src}")
            p_placeholder = doc.add_paragraph(f"[Image placeholder: {image_alt}]")
            p_placeholder.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p_placeholder.paragraph_format.space_after = after_spacing
            return
    try:
        pic_para = doc.add_paragraph() # Add image in its own paragraph for alignment
        pic_run = pic_para.add_run()
        pic_run.add_picture(img_path, width=width_inches)
        pic_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        pic_para.paragraph_format.space_after = Pt(0) 
    except Exception as e:
        print(f"Error adding picture {img_path}: {e}")
        p_placeholder = doc.add_paragraph(f"[Error adding image: {image_alt}]")
        p_placeholder.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_placeholder.paragraph_format.space_after = after_spacing
        return

    parent = img_soup.parent
    if parent and parent.name == 'div' and 'image-container' in parent.get('class', []):
        caption_div = parent.find('div', class_='image-caption')
        if caption_div:
            caption_text = caption_div.get_text().strip()
            caption_p = doc.add_paragraph()
            caption_run = caption_p.add_run(caption_text)
            caption_p.style = 'Caption'
            caption_run.font.name = "Arial"
            caption_run.italic = True
            caption_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            caption_p.paragraph_format.space_before = Pt(6)
            caption_p.paragraph_format.space_after = after_spacing

def simple_add_table(doc, table_soup, after_spacing_for_block=DEFAULT_AFTER_SPACING, table_number=None):
    """Add a table to the document, with numbered caption below the table."""
    caption_text_original = ""
    caption_div = table_soup.find_previous_sibling('div', class_='table-caption')
    if caption_div:
        caption_text_original = caption_div.get_text().strip()

    rows_soup = table_soup.find_all('tr')
    if not rows_soup: return
    num_rows = len(rows_soup)
    num_cols = max(len(row.find_all(['td', 'th'])) for row in rows_soup) if num_rows > 0 else 0
    if num_cols == 0: return

    table = doc.add_table(rows=num_rows, cols=num_cols)
    table.style = 'Table Grid'

    for i, row_s in enumerate(rows_soup):
        cells_s = row_s.find_all(['td', 'th'])
        for j, cell_s in enumerate(cells_s):
            if j < num_cols:
                cell_text = cell_s.get_text().strip()
                table_cell = table.cell(i, j)
                p_cell = table_cell.paragraphs[0] if table_cell.paragraphs else table_cell.add_paragraph()
                p_cell.text = "" # Clear previous content
                run = p_cell.add_run(cell_text)
                run.font.name = "Arial"
                table_cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
                if cell_s.name == 'th':
                    p_cell.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    run.font.bold = True
                    try:
                        from docx.oxml import parse_xml
                        from docx.oxml.ns import nsdecls
                        shading_elm = parse_xml(r'<w:shd {} w:fill="002A4E"/>'.format(nsdecls('w')))
                        table_cell._tc.get_or_add_tcPr().append(shading_elm)
                        run.font.color.rgb = RGBColor(255, 255, 255)
                    except Exception as e:
                        print(f"Could not set cell background for table header: {e}")
    
    # Add caption below the table
    if caption_text_original:
        # Add a small paragraph for spacing between table and caption if table doesn't have bottom margin
        # Or rely on caption's space_before.
        caption_p = doc.add_paragraph() # New paragraph for caption
        final_caption_text = f"Table {table_number}: {caption_text_original}" if table_number else caption_text_original
        caption_run = caption_p.add_run(final_caption_text)
        caption_p.style = 'Caption'
        caption_run.font.name = "Arial" # Ensure, though style should handle
        caption_run.italic = True      # Ensure
        caption_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        caption_p.paragraph_format.space_before = Pt(6) # Space between table and caption
        caption_p.paragraph_format.space_after = after_spacing_for_block # Space after caption
    else:
        # If no caption, ensure there's spacing after the table
        # The last paragraph of the table itself usually doesn't control this.
        # Add a spacing paragraph if the table was the last thing.
        if doc.paragraphs and doc.paragraphs[-1] is not None: # Check if last element was the table
             # This is tricky. The table itself is not a paragraph.
             # Add a new paragraph for spacing after the table.
             spacing_after_table_p = doc.add_paragraph()
             spacing_after_table_p.paragraph_format.space_before = Pt(0)
             spacing_after_table_p.paragraph_format.space_after = after_spacing_for_block
             for r_ in spacing_after_table_p.runs: r_.clear() # Make it visually empty

def simple_add_definition_list(doc, dl_soup, after_spacing=DEFAULT_AFTER_SPACING):
    """Adds a definition list (dl, dt, dd) to the document."""
    terms_definitions = []
    current_term_parts = []
    for child_tag in dl_soup.children:
        if child_tag.name == 'dt':
            if current_term_parts:
                terms_definitions.append({'term': " ".join(current_term_parts).strip(), 'def': ''})
                current_term_parts = []
            current_term_parts.append(child_tag.get_text().strip())
        elif child_tag.name == 'dd':
            term_to_use = " ".join(current_term_parts).strip() if current_term_parts else ""
            terms_definitions.append({'term': term_to_use, 'def': child_tag.get_text().strip()})
            current_term_parts = []
    if current_term_parts:
        terms_definitions.append({'term': " ".join(current_term_parts).strip(), 'def': ''})

    for i, item in enumerate(terms_definitions):
        if item['term']:
            p_term = doc.add_paragraph()
            run_term = p_term.add_run(item['term'])
            run_term.font.name = "Arial"; run_term.bold = True
            p_term.paragraph_format.space_after = Pt(0)
            if i > 0: p_term.paragraph_format.space_before = LIST_ITEM_AFTER_SPACING
        
        p_def = doc.add_paragraph() # Definition always gets a paragraph
        run_def = p_def.add_run(item['def'])
        run_def.font.name = "Arial"
        if item['term']: # Indent only if it's a definition for a term
            p_def.paragraph_format.left_indent = Inches(0.35)
        
        if i == len(terms_definitions) - 1:
            p_def.paragraph_format.space_after = after_spacing
        else:
            p_def.paragraph_format.space_after = LIST_ITEM_AFTER_SPACING


def get_next_significant_sibling(element):
    """Finds the next sibling that is a tag, not a table-caption div."""
    node = element
    while node.next_sibling:
        node = node.next_sibling
        if node.name and not (node.name == 'div' and 'table-caption' in node.get('class', [])):
            return node
    return None

def simple_html_to_docx(args):
    """Convert HTML to DOCX using a simplified approach."""
    with open(args.input, 'r', encoding='utf-8') as f: html_content = f.read()
    soup = BeautifulSoup(html_content, 'html.parser')
    metadata = extract_metadata(soup)
    
    if args.metadata and os.path.exists(args.metadata):
        import yaml
        try:
            with open(args.metadata, 'r', encoding='utf-8') as f:
                yaml_metadata = yaml.safe_load(f)
                if yaml_metadata: metadata.update(yaml_metadata)
        except Exception as e: print(f"Warning: Could not load metadata from {args.metadata}: {e}")
    
    doc = Document(args.template)
    default_font_settings(doc)
    if metadata: simple_update_metadata(doc, metadata)
    
    content_elements_to_process = []
    metadata_div_found = soup.select_one('div.metadata')
    body_content = soup.body
    if not body_content: print("Error: No <body> tag found."); return

    for element in body_content.children:
        if element == metadata_div_found: continue
        if element.name:
            if element.name == 'div' and 'table-caption' in element.get('class', []): continue
            content_elements_to_process.append(element)
            
    h1_counter = 0
    table_counter = 0
    prev_element_dom = None
    
    for i, element in enumerate(content_elements_to_process):
        is_first_content_element_in_body = (i == 0)
        next_sibling_element = get_next_significant_sibling(element)
        
        # Default after spacing for current element
        current_el_after_spacing = DEFAULT_AFTER_SPACING 

        if element.name == 'h1':
            h1_counter += 1
            # Assuming HTML for H1 is clean of numbers due to prompt change for Md-HTML stage
            text_content = element.get_text().strip()
            heading = doc.add_heading('', level=1) # Clear existing, then add run
            
            if not is_first_content_element_in_body :
                 heading.paragraph_format.space_before = HEADING_BEFORE_SPACING
            
            if next_sibling_element and next_sibling_element.name in ['ul', 'ol']:
                heading.paragraph_format.space_after = HEADING_AFTER_SPACING_BEFORE_LIST
            else:
                heading.paragraph_format.space_after = HEADING_AFTER_SPACING_NORMAL
            
            run = heading.add_run(f"{h1_counter}. {text_content}")
            run.font.color.rgb = RGBColor(0, 42, 78); run.font.bold = True
            run.font.size = Pt(16); run.font.name = "Arial"
        
        elif element.name in ['h2', 'h3']:
            level = 2 if element.name == 'h2' else 3
            text_content = element.get_text().strip() # Assume clean text
            heading = doc.add_heading(text_content, level=level)
            heading.paragraph_format.space_before = HEADING_BEFORE_SPACING
            
            if next_sibling_element and next_sibling_element.name in ['ul', 'ol']:
                heading.paragraph_format.space_after = HEADING_AFTER_SPACING_BEFORE_LIST
            else:
                heading.paragraph_format.space_after = HEADING_AFTER_SPACING_NORMAL

            size = Pt(14) if level == 2 else Pt(12)
            for run in heading.runs:
                run.font.color.rgb = RGBColor(0, 42, 78); run.font.bold = True
                run.font.size = size; run.font.name = "Arial"

        elif element.name == 'p':
            p_doc = doc.add_paragraph()
            for child in element.children:
                if isinstance(child, NavigableString): run = p_doc.add_run(str(child))
                elif child.name == 'strong': run = p_doc.add_run(child.get_text()); run.bold = True
                elif child.name == 'em': run = p_doc.add_run(child.get_text()); run.italic = True
                else: run = p_doc.add_run(child.get_text()) # Fallback
                run.font.name = "Arial"

            if next_sibling_element and next_sibling_element.name in ['ul', 'ol']:
                p_doc.paragraph_format.space_after = PARAGRAPH_AFTER_SPACING_BEFORE_LIST
            else:
                p_doc.paragraph_format.space_after = DEFAULT_AFTER_SPACING
        
        elif element.name == 'div' and 'pagebreak' in element.get('class', []):
            doc.add_page_break()
        
        elif element.name == 'div' and 'image-container' in element.get('class', []):
            img_tag = element.find('img')
            if img_tag: simple_add_image(doc, img_tag, args.images_dir, DEFAULT_AFTER_SPACING)
        
        elif element.name == 'table':
            table_counter += 1
            # simple_add_table now manages its own after_spacing for the entire block
            simple_add_table(doc, element, DEFAULT_AFTER_SPACING, table_counter) 
            
        elif element.name == 'ul' or element.name == 'ol':
            list_b_spacing = LIST_DEFAULT_BEFORE_SPACING
            # If previous element was a heading or paragraph that already has reduced spacing before list
            if prev_element_dom and prev_element_dom.name in ['h1', 'h2', 'h3', 'p']:
                # Check the actual space_after of the last paragraph added to doc for that element
                # This requires that doc.paragraphs[-1] IS the paragraph from prev_element_dom
                # This can be fragile. A more robust way is to rely on the next_sibling check of prev element.
                # For now, assume if prev_element's space_after was set to _BEFORE_LIST, list needs less/no before_spacing
                # This logic is tricky. Let simple_add_list handle its default `before_spacing` unless
                # the calling context (like list-intro para) specifically sets it to 0.
                # For now, pass default. If prev element (heading/para) reduced its after_spacing, it should be enough.
                pass # Use default list_b_spacing, heading/para should have handled its after_spacing.

            simple_add_list(doc, element, ordered=(element.name == 'ol'), 
                            after_spacing=DEFAULT_AFTER_SPACING, 
                            before_spacing=list_b_spacing, 
                            indent_level=0)
        
        elif element.name == 'dl':
            simple_add_definition_list(doc, element, DEFAULT_AFTER_SPACING)

        elif element.name == 'pre':
            p_pre = doc.add_paragraph()
            run_pre = p_pre.add_run(element.get_text()) # get_text() usually preserves newlines from <pre>
            run_pre.font.name = "Courier New"; # run_pre.font.size = Pt(10)
            p_pre.paragraph_format.space_after = DEFAULT_AFTER_SPACING
            
        prev_element_dom = element
            
    doc.save(args.output)
    print(f"Converted {args.input} to {args.output} successfully.")

def main():
    args = parse_arguments()
    if not os.path.exists(args.input): print(f"Input file {args.input} does not exist"); sys.exit(1)
    if not os.path.exists(args.template): print(f"Template file {args.template} does not exist"); sys.exit(1)
    output_dir = os.path.dirname(os.path.abspath(args.output))
    if output_dir: os.makedirs(output_dir, exist_ok=True)
    simple_html_to_docx(args)

if __name__ == "__main__":
    main()